import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class sketch_210625b extends PApplet {

float speed = 5f;
float xPos = width / 2;
float yPos = height / 2;
int score = 0;
PFont f;
Coordinate[] snake = {new Coordinate(width / 2, height / 2)};
int size = 1;
int highscore = 0;

enum Direction {
  UP,
  DOWN,
  LEFT,
  RIGHT
}
Direction dir = Direction.RIGHT; 

public void setup() {
  
  readHighScore();
  f = createFont("Arial", 16, true);
}

public void draw() {
  background(255, 255, 255);
  textFont(f, 36);
  fill(0);
  text("Score: " + score, 10, 50);
  text("Highscore: " + highscore, 10, height - 50);
  render();
  if (keyPressed) {
    testKeyPress();
  }
  move();
  generateApple();
  testTouchingApple();
  handleSnake();
  testCollision();
  if (score > highscore) highscore = score;
}

public void handleSnake() {
  for (int i = snake.length - 1; i > -1; i--) {
    if (i == 0) {
      snake[i] = new Coordinate(xPos, yPos);
    } else {
      snake[i] = snake[i - 1];
    }
  }
}

public void readHighScore() {
  InputStream input = createInput("hs.txt");
  String content = "";
  
  BufferedReader reader = createReader("hs.txt");
  String line = null;
  try {
    while ((line = reader.readLine()) != null) {
      content += line;
    }
    reader.close();
  } catch (IOException e) {
    e.printStackTrace();
  }
  if (content == "") {
    highscore = 0;
  } else {
    highscore = PApplet.parseInt(content);
  }
}

public void render() {
  rectMode(CENTER);
  fill(0, 0, 0);
  for (int i = 0; i < snake.length; i++) {
    rect(snake[i].x, snake[i].y, 25, 25);
  }
}

public void move() {
  switch (dir) {
    case UP:
      yPos -= speed;
      break;
    case DOWN:
      yPos += speed;
      break;
    case LEFT:
      xPos -= speed;
      break;
    case RIGHT: 
      xPos += speed;
      break;
  }
}

public void testCollision() {
  for (int i = 25; i < snake.length; i++) {
    Coordinate c = snake[i];
    if ((xPos < c.x + 12.5f) && (xPos > c.x - 12.5f) && (yPos < c.y + 12.5f) && (yPos > c.y - 12.5f)) {
      PrintWriter output = createWriter("data/hs.txt");
      output.print(highscore);
      output.flush();
      output.close();
      exit();
    }
  }
  if (((xPos < 0) || (xPos > width)) || ((yPos < 0) || (yPos > height))) {
    PrintWriter output = createWriter("data/hs.txt");
    output.print(highscore);
    output.flush();
    output.close();
    exit();
  }
}

public void testKeyPress() {
  switch (key) {
    case 'w': 
      if (dir != Direction.DOWN)
      dir = Direction.UP;
      break;
    case 's':
      if (dir != Direction.UP)
      dir = Direction.DOWN;
      break;
    case 'a': 
      if (dir != Direction.RIGHT)
      dir = Direction.LEFT;
      break;
    case 'd':
      if (dir != Direction.LEFT)
      dir = Direction.RIGHT;
      break;
  }
}

Apple apple = null;

public void testTouchingApple() {
  if (apple == null) return;
  apple.drawApple();
  if (apple.testTouching(xPos, yPos, 50)) {
    score++;
    size++;
    apple = null;
    Coordinate[] temp = snake;
    snake = new Coordinate[size];
    for (int i = 0; i < temp.length; i++) {
      snake[i] = temp[i];
    }
  }
}

public void generateApple() {
  if (apple != null) return;
  int r = 0;
  if (r == 0) {
    float x = random(width);
    float y = random(height);
    apple = new Apple(x, y);
  }
}

class Apple {
   private float x;
   private float y;
   
   public Apple(float x, float y) {
     this.x = x;
     this.y = y;
   }
   
   public void drawApple() {
     stroke(0);
     fill(255, 10, 10);
     ellipseMode(CENTER);
     ellipse(x, y, 10, 10);
   }
   
   public boolean testTouching(float x, float y, float range) {
     if (((this.x + range / 2) > x) && ((this.x - range / 2) < x)) {
       if (((this.y + range / 2) > y) && ((this.y - range / 2) < y)) {
         return true;
       }
     }
     return false;
   }

}

class Coordinate {
  
  public float x;
  public float y;
  
  public Coordinate(float x, float y) {
    this.x = x;
    this.y = y;
  }
  
}
  public void settings() {  size(900, 550); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "sketch_210625b" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
